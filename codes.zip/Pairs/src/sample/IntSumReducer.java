package sample;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class IntSumReducer 
extends Reducer<Pair,DoubleWritable,Pair,DoubleWritable> {
	private DoubleWritable result = new DoubleWritable();
    private DoubleWritable result1=new DoubleWritable();
 
    DoubleWritable densum=new DoubleWritable();
	Text current_word=new Text();
    public void reduce(Pair key, Iterable<DoubleWritable> values, Context context) throws IOException, InterruptedException {
		System.out.println("recvd="+key.toString());	
			if(key.getcoword().toString().equals("*"))
			{
				System.out.println("* recvd");
				if(current_word.toString().equals(key.getword().toString()))
				densum.set(densum.get()+getcount(values));
				else
				{
					current_word.set(key.getword().toString());
					densum.set(0);
					densum.set(getcount(values));
				}
			}
			else
			{
				double count = getcount(values);
	            result.set(count);
	           
				result1.set((double)count/densum.get());
	            System.out.println("writeen values "+count);
	            context.write(key, result);
	            context.write(key,result1);
				
			}
	
		
	}
    private int getcount(Iterable<DoubleWritable> values) 
	{
        int sum = 0;
        for (DoubleWritable value : values) {
            sum += value.get();
        }
        return sum;
    }
}
