package sample;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class PairReducer 
extends Reducer<Pair,DoubleWritable,Pair,DoubleWritable> {
	private DoubleWritable result = new DoubleWritable();

	public void reduce(Pair key, Iterable<DoubleWritable> values, Context context) throws IOException, InterruptedException {
		int sum = 0;
		for (DoubleWritable val : values) {
			sum += val.get();
		}
		result.set(sum);
		context.write(key, result);
	}
}
