
package sample;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;
public class PairPartitioner extends Partitioner<Pair, DoubleWritable> {

@Override
public int getPartition(Pair key, DoubleWritable value, int numPartitions) {
	// TODO Auto-generated method stub
	
	return  Math.abs(key.getword().toString().hashCode()) % numPartitions;
}

}