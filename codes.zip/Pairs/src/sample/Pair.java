package sample;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;

public class Pair implements Writable,WritableComparable<Pair> {
 Text word;
 Text coword;
 
  Pair(String wo,String cow)
  {
	this.word=new Text(wo);
	this.coword=new Text(cow);
  }
  
  Pair(Text wo,Text cow)
  {
	  this.word=wo;
	  this.coword=cow;
  }
  
  Pair()
  {
	  this.word=new Text();
	  this.coword= new Text();
  }
  public String toString()
  {
	  
	return "wo ="+word.toString()+"\t co ="+coword.toString()+"\t";
	  
  }
  
  public Text getword()
  {
	  return this.word;
  }

  public Text getcoword()
  {
	  return this.coword;
  }

@Override
public int compareTo(Pair o) {
int returnVal = this.getword().toString().compareTo(o.getword().toString());
      if(returnVal!=0)
      {
    	  return returnVal;
      }
        if(this.coword.toString().equals("*") && o.getcoword().toString().equals("*"))
        {
            return 0;
        }
        else 
         return this.getcoword().toString().compareTo(o.getcoword().toString()); 
    
}

@Override
public void readFields(DataInput di) throws IOException {
	// TODO Auto-generated method stub
	word.readFields(di);
	coword.readFields(di);
	
}

@Override
public void write(DataOutput dout) throws IOException {
	// TODO Auto-generated method stub
	word.write(dout);
    coword.write(dout);
	
}

public void setword(String string) {
	// TODO Auto-generated method stub
	this.word.set(string);
}

public void setcoword(String string) {
	// TODO Auto-generated method stub
	this.coword.set(string);
	
}
}
