package sample;

import java.io.IOException;
import java.util.StringTokenizer;
import java.util.Vector;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class TokenizerMapper extends Mapper<Object, Text, Pair, DoubleWritable>{

	private final static DoubleWritable one = new DoubleWritable(1);
	private Text word = new Text();
    private Pair hashes=new Pair();

    
	public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
		StringTokenizer stk=new StringTokenizer(value.toString(),"#");
		Vector <String>v=new Vector<String>();
		while(stk.hasMoreTokens())
		{
			v.add(stk.nextToken());
		}
		String all_hashes[]=v.toArray(new String[v.size()]);
		
		for(int i=0;i<all_hashes.length;i++)
		{
			for(int j=0;j<all_hashes.length;j++)
			{
				if(all_hashes[i].equalsIgnoreCase(all_hashes[j]))
				{
					continue;					
				}
				else
				{
					hashes.setword(all_hashes[i]);
					hashes.setcoword(all_hashes[j]);
					context.write(hashes, one);
					System.out.println(hashes.toString());
					context.write(new Pair(hashes.getword().toString(),"*"),one);
				}
			
			}
			
			
		}
		
		
		
	}
}