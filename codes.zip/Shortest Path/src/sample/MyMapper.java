package sample;

import java.io.IOException;
import java.util.StringTokenizer;
import java.util.Vector;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper <LongWritable, Text, LongWritable, Text>
{
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
	{
		String val= value.toString();
		String [] tokWord= val.split(" ");
		StringTokenizer stk=new StringTokenizer(val);
		Vector<String> token=new Vector<String>();
		while(stk.hasMoreTokens())
		{
			token.add(stk.nextToken());
		}
		if(!token.isEmpty() && token!=null)
		{
			int dist= Integer.parseInt(token.get(1))+1;
			String[] nbrs= token.get(2).split(":");
			boolean flag=true;
			if(key.equals(null) || value.equals(null) || context.equals(null))
			{
				flag=false;
				System.out.println("Something is null in MAPPER!");
			}
			if(flag==true)
			{
			for(String nbr: nbrs)
			{
				context.write(new LongWritable(Integer.parseInt(nbr)), new Text("DISTANCE "+ Integer.toString(dist)));
			}
			context.write(new LongWritable(Integer.parseInt(token.get(0))), new Text("DISTANCE "+ Integer.parseInt(token.get(1))));
			context.write(new LongWritable(Integer.parseInt(token.get(0))), new Text("ADJLIST "+ token.get(2)));
			}
		}
		}
}