package sample;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.Vector;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ShortestPath {

	private static final transient Logger LOG = LoggerFactory.getLogger(ShortestPath.class);

	public static void main(String[] args) throws Exception {
		
		Configuration conf = new Configuration();
		Job job = null;
		LOG.info("HDFS Root Path: {}", conf.get("fs.defaultFS"));
		LOG.info("MR Framework: {}", conf.get("mapreduce.framework.name"));
		/* Set the Input/Output Paths on HDFS */
		//String inputPath = "/input";
		String outputPath = "/output";
		String hardCodedPath= "/SPath";
		String inpfile="/SPath/graph.txt";
		String outputfile="/SPath/part-r-00000"+ System.nanoTime();
		System.out.println("D----O----N----E----");
		Path hcp=new Path(hardCodedPath);
		boolean isComplete=false, success=false;;int count=0;
		Hashtable<Integer, Integer> baseMap=new Hashtable<Integer, Integer>();
		Hashtable<Integer, Integer> compMap=new Hashtable<Integer, Integer>();
		
		/* FileOutputFormat wants to create the output directory itself.
		 * If it exists, delete it:
		 */
		deleteFolder(conf,outputPath);
		while(isComplete!=true){
	/*	JobConf config = new JobConf(WordCount.class);
		config.setMapOutputKeyClass(Text.class);
		config.setMapOutputValueClass(MapWritable.class);*/
		job = Job.getInstance(conf);
		job.setJarByClass(ShortestPath.class);
		job.setMapperClass(MyMapper.class);
		//job.setCombinerClass(IntSumReducer.class);
		job.setReducerClass(MyReducer.class);
		job.setMapOutputKeyClass(LongWritable.class);
		job.setMapOutputValueClass(Text.class);
		job.setOutputKeyClass(LongWritable.class);
		job.setOutputValueClass(Text.class);
		//job.setNumReduceTasks(1);
		System.out.println("Ipfile "+ inpfile);
		System.out.println("opfile "+ outputfile);
		FileInputFormat.addInputPath(job, new Path(inpfile));
		FileOutputFormat.setOutputPath(job, new Path(outputfile));
		success=job.waitForCompletion(true);
		
		deleteFile(conf,inpfile);
		
		
        inpfile = outputfile+"/part-r-00000";
        outputfile = "/part-r-00000" + System.nanoTime();
        
		count=count+1;
		isComplete=true;
		BufferedReader br=null;
		if(count>=1){
		Path p=new Path(inpfile);
		FileSystem fs=FileSystem.get(conf);
		br=new BufferedReader(new InputStreamReader(fs.open(p)));
		}
		String line=br.readLine();
		while(line!=null)
		{
			String[] tokens= line.split(" ");	//InP : [1 0 2:3:]
			StringTokenizer stk=new StringTokenizer(line);
			Vector<String> token=new Vector<String>();
			while(stk.hasMoreTokens())
			{
				token.add(stk.nextToken());
			}
			System.out.println("Line = "+ line);
			System.out.println("Token0 "+token.get(0));
			System.out.println("Token1 "+token.get(1));
			int n=Integer.parseInt(token.get(0));
			int d=Integer.parseInt(token.get(1));
			baseMap.put(n, d);
			line=br.readLine();
		}
		if(count==0 || count==1 || (compMap.isEmpty()))
		{
			//Job has ran only once, forcefully do another iteration
			//If(compMap.isEmpty)
		
			isComplete=false;
		
		}
		else
		{
			System.out.println("Basemap "+ baseMap);
			System.out.println("CompMap "+ compMap);
			if(baseMap.equals(null))
			{
				System.out.println("BaseMap is null!");
			}
			Iterator<Integer> itr=baseMap.keySet().iterator();
			while(itr.hasNext())
			{
				int k=itr.next();
				int v=baseMap.get(k);
				if(v!=compMap.get(k))
				{
					isComplete=false;
				}
			}
		}
		if(isComplete==false)
		{
			compMap.putAll(baseMap);
		}
			
		
		}
		
		System.exit(success ? 0 : 1);
	}
	
	private static void deleteFile(Configuration conf, String fileName) throws IOException {
	    FileSystem fileSystem = FileSystem.get(conf);

	    Path path = new Path("/SPath"+fileName);
	    if (!fileSystem.exists(path)) {
	        System.out.println("File does not exists");
	        return;
	    }

	    // Delete file
	    fileSystem.delete(path, true);

	    fileSystem.close();
		
	}

	/**
	 * Delete a folder on the HDFS. This is an example of how to interact
	 * with the HDFS using the Java API. You can also interact with it
	 * on the command line, using: hdfs dfs -rm -r /path/to/delete
	 * 
	 * @param conf a Hadoop Configuration object
	 * @param folderPath folder to delete
	 * @throws IOException
	 */
	private static void deleteFolder(Configuration conf, String folderPath ) throws IOException {
		FileSystem fs = FileSystem.get(conf);
		Path path = new Path(folderPath);
		if(fs.exists(path)) {
			fs.delete(path,true);
		}
	}
}