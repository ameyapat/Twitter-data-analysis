package sample;

import java.io.IOException;
import java.util.StringTokenizer;
import java.util.Vector;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MyReducer extends Reducer <LongWritable, Text, LongWritable, Text>
{
	public void reduce(LongWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException
	{
		int startDistance=10000;
		String nodeList=null;
		boolean flag=true;
		if(key.equals(null) || values.equals(null) || context.equals(null))
		{
			flag=false;
			System.out.println("Something is null in REDUCER!");
		}
		for(Text val: values)
		{
			String value= val.toString();
			String [] tokens= value.split(" ");
			StringTokenizer stk=new StringTokenizer(value);
			Vector<String> token=new Vector<String>();
			while(stk.hasMoreTokens())
			{
				token.add(stk.nextToken());
			}
			if(!token.isEmpty())
			{
				if(token.get(0).equalsIgnoreCase("ADJLIST") && flag==true)
				{
					nodeList=token.get(1);
				}
				else if(token.get(0).equalsIgnoreCase("DISTANCE") && flag==true)
				{
					
					//distance=Integer.parseInt(tokens[1]);
					startDistance=Math.min(Integer.parseInt(token.get(1)), startDistance);
								
				}
			}
		  }
		System.out.println("In reducer = "+startDistance+" "+nodeList);
		context.write(key, new Text(startDistance+" "+nodeList));
		
	}
}