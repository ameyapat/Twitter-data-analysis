package sample;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;

import org.apache.hadoop.hdfs.util.EnumCounters.Map;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Mapper;

public class TokenizerMapper extends Mapper<LongWritable,Text,Text,MapWritable>{

	private final static IntWritable one = new IntWritable(1);
	//private Text word = new Text();
	MapWritable map= new MapWritable();
	Text w;
	
	private String curr;

	void printMap(MapWritable m)
	{
		Set<Writable> keys = m.keySet();
		for(Writable key: keys)
		{
			System.out.println(key+ "   " + m.get(key));
		}
		
		
	}
	@Override
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		StringTokenizer itr = new StringTokenizer(value.toString());
		
		
	//	itr.nextToken();
		/*while (itr.hasMoreTokens()) {
			String temp= itr.nextToken();
			//IntWritable tmp= new IntWritable(); 
			//tmp=one;
			w=new Text(temp);
		if(map.containsKey(w))
		{
			IntWritable c= (IntWritable) map.get(w); 
			c.set(c.get()+1);
			map.put(w,c );
			System.out.println("For key "+ w +" Map being sent to reducer is ");
			printMap(map);
			context.write(w, map);
		}
		else{
		System.out.println("For key "+ w +" Map being sent to reducer is ");
		printMap(map);
		map.put(w,one);
		context.write(w, map);
		}
		
		}*/
		
		StringTokenizer tokWord = new StringTokenizer(value.toString());
		Vector<String> v= new Vector<String> ();
		Vector<String> neighbours= new Vector<String> ();
		while(tokWord.hasMoreTokens())
		{
			v.add(tokWord.nextToken());
		}
		System.out.println("v= "+v);
		for(int i=0; i<v.size();i++)
			
		{
			curr=v.get(i);
			
			for(int j=0; j< v.size(); j++)
			{
				if(i==j) continue;
				else
				{
					neighbours.add(v.get(j));
				}
				
			}
			System.out.println("neighbours = "+neighbours);
			for(int k=0; k< neighbours.size(); k++)
			{
				//WordCount.objectmap.put(new Text(curr), map);
				if(!WordCount.objectmap.containsKey(new Text (curr)))
				{
					WordCount.objectmap.put(new Text(curr), map);
				}
				System.out.println("To check if ");
				printMap(WordCount.objectmap.get(new Text(curr)));
				System.out.println(" has key "+ neighbours.get(k));				
				if(WordCount.objectmap.get(new Text(curr)).containsKey(neighbours.get(k)))
				{
					IntWritable c= ((IntWritable) WordCount.objectmap.get(curr).get(neighbours.get(k))); 
					IntWritable c1= ((IntWritable) WordCount.objectmap.get(curr).get(neighbours.get(k))); 
					c.set(c.get()+1);
					w=new Text(v.get(i));
					System.out.println("Key " + w+ " existes, replacing "+ c1 +" with "+ c );
					map.put(w,c );
				}
				else
				{
					w=new Text(neighbours.get(k));
					System.out.println("First time add: "+w.toString());
					map.put(w, one);
				}
			}
			Text t=new Text(v.get(i));
			WordCount.objectmap.put(new Text(curr), map);
			System.out.println("For key "+ t +" Map being sent to reducer is ");
			printMap(WordCount.objectmap.get(new Text(curr)));
			//processmap(t,map); TODO
			
			System.out.println("map = " );printMap(map);
			context.write(t, WordCount.objectmap.get(new Text(curr)));
			neighbours.clear();
		}
		}
	}
