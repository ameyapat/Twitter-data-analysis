package sample;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;


public class IntSumReducer extends Reducer<Text, MapWritable, Text, Text> {
    private MapWritable map = new MapWritable();
	private double sum=0;
	

    private Text MapToString(MapWritable m, Writable key)
	{
    	 
    	double summ=0, rlf=0, sumt=0;
    	 Set<Writable> ks= m.keySet();
         for(Writable k:ks)
         {
         	summ=summ+((IntWritable)( m.get(key))).get();
         	
         }
         if(summ%2==0)
         {
        	 sumt=summ/2;
         }
         else sumt=summ;
         int pairsum=(int)( (IntWritable) m.get(key)).get();
         System.out.println( ((IntWritable)( m.get(key))).get() +" Summ = "+sumt + " rlf= " + pairsum/(sumt));
         
         
         
		rlf = pairsum/(sumt);
		
		return new Text(key.toString()+ " " + rlf + " "+ ((IntWritable)( m.get(key))).get());
		//return new Text(key.toString()+ " " + ((IntWritable)( map.get(key))).toString());
		//return new Text(key.toString()+ " " + sum);
		
	}
    @Override
    protected void reduce(Text key, Iterable<MapWritable> values, Context context) throws IOException, InterruptedException {
        map.clear();
        
        for (MapWritable val : values) {
            Add(val);
        }
        MapWritable mapmod= new MapWritable();
		//mapmod=ProcessMap(map, key);
        Set<Writable> ks= map.keySet();
        for(Writable k:ks)
        {
        	
        }
        for(Writable k: ks)
		{
			if(key.toString().equalsIgnoreCase(k.toString())) continue;
			else {
				
				context.write(key, MapToString(map, k));}
		}
    sum=0;  
    }

    private MapWritable ProcessMap(MapWritable m2, Text key) {
		Set<Entry<Writable,Writable>> me= m2.entrySet();
		for(Entry<?, ?> e: me)
		{
			if(e.getKey().equals(key))
			{
				m2.remove(key);
			}
		}
		return m2;
	}
	private Text MapWrite(MapWritable m, Text k) {
    	double o=((IntWritable)( m.get(k))).get()/sum;
    	return new Text(k.toString()+ " " + o + " "+ ((IntWritable)( m.get(k))).get());
    	
    	
		
	}
	private void Add(MapWritable mapp) {
        Set<Writable> keys = mapp.keySet();
        for (Writable key : keys) {
            IntWritable sourceCount = (IntWritable) mapp.get(key);
            if (map.containsKey(key)) {
                IntWritable count = (IntWritable) map.get(key);
                count.set(count.get() + sourceCount.get());
                sum = sum + sourceCount.get();
            } else {
                map.put(key, sourceCount);
                sum = sum + sourceCount.get();
            }
        }
    }
}
