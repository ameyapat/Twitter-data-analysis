package sample;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;

public class User {

	DoubleWritable nof=new DoubleWritable();
	Text username=new Text();
	
	User()
	{
	 this.nof.set(0);
	 this.username.set("");
	}
	
	User(String s,double dw)
	{
		this.nof.set(dw);
		this.username.set(s);
		
	}
	
	double getnof()
	{
		return this.nof.get();
	}
	
    public String toString()
    {
    	return "username="+username.toString()+" "+"No.ofFoll = "+nof.get();
    }
	
}
