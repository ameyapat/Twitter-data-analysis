package sample;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;


public class KMapper extends Mapper<LongWritable, Text, DoubleWritable, DoubleWritable>{

    User usr;
    static double low_cent=0,med_cent=0,high_cent=0;
	static double new_low_cent=0,new_med_cent=0,new_high_cent=0;
    static int flag=0,fl=0;
    
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException 
	{
	  String tmp[]=value.toString().split(" ");
	
	  double dq=Double.parseDouble(tmp[1]);
	  
	  usr=new User(tmp[0],dq);
	 
	 
	  Job job = Job.getInstance(context.getConfiguration());
	  long counter = context.getCounter(sample.KmeansDriver.UpdateCounter.UPDATED).getValue();

	  
		  
		  Path pt1=new Path("hdfs://ubuntu:8020/flag.txt");
	      FileSystem fs1 = FileSystem.get(context.getConfiguration());
	      if(fs1.exists(pt1))
	      {
	    	  try
			  {
	      BufferedReader obj=new BufferedReader(new InputStreamReader(fs1.open(pt1)));
		  flag=Integer.parseInt(obj.readLine());
	     // System.out.println("Flag in mapper = "+flag);
		  }
		  catch(Exception e)
		  {System.out.println("Unable to get flag"+e);}
		  }
	  
      if(flag==0)  // 1st iteration
	  {
    	  fl=1;
		  low_cent=150;
		  med_cent=700;
		  high_cent=2000;
		  
		  double clid=getClusterId(usr.getnof(),low_cent,med_cent,high_cent);
		  System.out.println("Sending.."+clid+","+usr.getnof());
		  context.write(new DoubleWritable(clid),new DoubleWritable(usr.getnof()));
		 
	  }
	  else
	  {
		  flag++;
		  context.getCounter(sample.KmeansDriver.UpdateCounter.UPDATED).increment(1);
		try{
			Path pt=new Path("hdfs://ubuntu:8020/cluster_details.txt");
            FileSystem fs = FileSystem.get(context.getConfiguration());
            if(fs.exists(pt))
            {
            BufferedReader obj=new BufferedReader(new InputStreamReader(fs.open(pt)));
		String tp[]=obj.readLine().split(" ");
		//System.out.println("read = "+ tp[0]+tp[1]+tp[2]);
		new_low_cent=Double.parseDouble(tp[0]);
		new_med_cent=Double.parseDouble(tp[1]);
		new_high_cent=Double.parseDouble(tp[2]);
		obj.close();
            
		
	    double wr=getClusterId(usr.getnof(),new_low_cent,new_med_cent,new_high_cent);
		//System.out.println("Sending == "+wr+","+usr.getnof());
		context.write(new DoubleWritable(wr),new DoubleWritable(usr.getnof()));
            }		
		}
		catch(Exception e)
		{
			System.out.println("Error in file read "+e);
		}
		
	  }
	  
	}
	int getClusterId(double nof,double l,double m,double h)
	{
		if(Math.abs(nof-l) < Math.abs(nof-m) && Math.abs(nof-l) < Math.abs(nof-h))
		return 0;
		else
		if(Math.abs(nof-m) < Math.abs(nof-l) && Math.abs(nof-m) < Math.abs(nof-h))
		return 1;
		else
		if(Math.abs(nof-h) < Math.abs(nof-l) && Math.abs(nof-h) < Math.abs(nof-m))
		return 2;
		
		return 0;
	}
}