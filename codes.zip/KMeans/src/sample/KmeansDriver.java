package sample;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class KmeansDriver {

	private static final transient Logger LOG = LoggerFactory.getLogger(KmeansDriver.class);
    public static enum UpdateCounter 
    {
    	UPDATED
    }
	
	private static boolean s;
	static boolean br_val=true;
    public static void main(String[] args) throws Exception {
		
		Configuration conf = new Configuration();		
        
		LOG.info("HDFS Root Path: {}", conf.get("fs.defaultFS"));
		LOG.info("MR Framework: {}", conf.get("mapreduce.framework.name"));
		/* Set the Input/Output Paths on HDFS */
		String inputPath = "/input";
		String outputPath = "/output";
        String tp[]=null;
		/* FileOutputFormat wants to create the output directory itself.
		 * If it exists, delete it:
		 */
		
		KMapper.flag=0;
        while(true && br_val)
        {
	    		deleteFolder(conf,outputPath);
	
	        Job job = Job.getInstance(conf);
			job.setJarByClass (KmeansDriver.class);
			job.setMapperClass(KMapper.class);
			job.setCombinerClass(KReducer.class);
			job.setReducerClass(KReducer.class);
		
			
			job.setOutputKeyClass(DoubleWritable.class);
			job.setOutputValueClass(DoubleWritable.class);
			
			FileInputFormat.addInputPath(job, new Path(inputPath));
			FileOutputFormat.setOutputPath(job, new Path(outputPath));
			try
			{
				Path pt=new Path("hdfs://ubuntu:8020/cluster_details.txt");
		           FileSystem fs = FileSystem.get(conf);
		           if(fs.exists(pt))
		           {
				BufferedReader obj=new BufferedReader(new InputStreamReader(fs.open(pt)));
				tp=obj.readLine().split(" ");
				LOG.info("Tp length = "+tp.length);
				obj.close();
					for(String a:tp)
					LOG.info(a);
				
					if(tp.length>=6)
					for(int i=0;i<tp.length-3;i++)
					if(tp[i].equalsIgnoreCase(tp[i+3]))
					{
						LOG.info("INFINITE LOOP BROKEN");
						br_val=false;
						break;
						
					}
		           }
			}
			catch(Exception e)
			{
				LOG.info("ERROR READING CENTROIDS");
			}
			s=job.waitForCompletion(true);

        }
        System.exit(s ? 0 : 1);
	}
	
	/**
	 * Delete a folder on the HDFS. This is an example of how to interact
	 * with the HDFS using the Java API. You can also interact with it
	 * on the command line, using: hdfs dfs -rm -r /path/to/delete
	 * 
	 * @param conf a Hadoop Configuration object
	 * @param folderPath folder to delete
	 * @throws IOException
	 */
	private static void deleteFolder(Configuration conf, String folderPath ) throws IOException {
		FileSystem fs = FileSystem.get(conf);
		Path path = new Path(folderPath);
		if(fs.exists(path)) {
			fs.delete(path,true);
		}
	}
}