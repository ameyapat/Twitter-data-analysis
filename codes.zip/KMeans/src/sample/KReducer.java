package sample;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Vector;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

public class KReducer extends Reducer<DoubleWritable,DoubleWritable,DoubleWritable,DoubleWritable> {
	
	Vector <DoubleWritable>clus0=new Vector<DoubleWritable>();
	Vector <DoubleWritable>clus1=new Vector<DoubleWritable>();
	Vector <DoubleWritable>clus2=new Vector<DoubleWritable>();
	int flg=0;
	String result=new String();
	public void reduce(DoubleWritable key, Iterable<DoubleWritable> values, Context context) throws IOException, InterruptedException 
	{
		 int clidd=-1;
		 
	      Iterator <DoubleWritable>i=values.iterator();
	    
	      
	      while(i.hasNext())
	      {
	    	 
	    	  DoubleWritable val= i.next();
	    	  //System.out.println("Added <"+key.get()+","+val.get()+">");
	    	  if(key.get()==0)
	    	  {
	    	  clus0.add(new DoubleWritable(val.get())); 
	    	  System.out.println("clus0 "+clus0);
	    	  result+=" cluster 0 : "+clus0.toString()+"\n";
	    	  
	    	  clidd=0;
	    	  }
	    	  if(key.get()==1)
	    	  {
	    		  clus1.add(new DoubleWritable(val.get()));
		    	 // System.out.println("clus1 "+clus1);
		    	  result+=" cluster 1 : "+clus1.toString()+"\n";
		    	  
	    		  clidd=1;
	    	  }
	    	  if(key.get()==2){
		    	clidd=2;
	    		  clus2.add(new DoubleWritable(val.get()));
	    		  //System.out.println("clus2 "+clus2);
	    		  result+=" cluster 2 : "+clus2.toString()+"\n";
		    	  
	    	  }
	      }
	      
	      try
	      {
	    	  Path pt=new Path("hdfs://ubuntu:8020/result.txt");
	           FileSystem fs = FileSystem.get(context.getConfiguration());
	           if(!fs.exists(pt))
	        	   fs.create(pt);
	           PrintWriter bw=new PrintWriter(new OutputStreamWriter(fs.append(pt)));
	           bw.println(result);  // incrementing flag
	           bw.flush();
	           bw.close();
	      }
	      catch(Exception e)
	      {
	    	  
	      }
	    
	      try
	      {
	    	  Path pt=new Path("hdfs://ubuntu:8020/flag.txt");
	           FileSystem fs = FileSystem.get(context.getConfiguration());
	           
	           BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(fs.create(pt,true)));
	           bw.write("1");  // incrementing flag
	           bw.flush();
	           bw.close();
	      }
	      catch(Exception e)
	      {
	    	  
	      }
	      context.getCounter(sample.KmeansDriver.UpdateCounter.UPDATED).increment(1);
	      try
	      {
	       int write_counter=0;
	       Path pt=new Path("hdfs://ubuntu:8020/cluster_details.txt");
           FileSystem fs = FileSystem.get(context.getConfiguration());
           BufferedWriter bw=null;
           if(fs.isFile(pt) && write_counter<2)
          {
        	   bw=new BufferedWriter(new OutputStreamWriter(fs.append(pt)));
        	   write_counter++;
          }
          else
          {
	      bw=new BufferedWriter(new OutputStreamWriter(fs.create(pt,true)));
	      write_counter=0;
          }
	      double ew=0;
	      if(clidd==0)
	      {
	      ew=getcentroid(clus0);
	      bw.write(ew+" ");
	      bw.flush();
	      //System.out.println("Wrote in file.. new cluster center = "+ew);
	      bw.close();
	      }
	      if(clidd==1)
	      {
	      ew=getcentroid(clus1);
		  bw.write(ew+" ");
	      bw.flush();
	      //System.out.println("Wrote in file.. new cluster center"+ew);
	      bw.close();
	      }
	      if(clidd==2)
	      {
	      ew=getcentroid(clus2);
		  bw.write(ew+" ");
	      bw.flush();
	      //System.out.println("Wrote in file.. new cluster center"+ew);
	      bw.close();
	      
	      }
	      context.write(new DoubleWritable(ew),new DoubleWritable());
	      }
	      catch(IOException e)
	      {
	    	  System.out.println("Error in FileWrite "+e);
	      }
	      
	      
	}
	
	double getcentroid(Vector<DoubleWritable> v)
	{
		 //System.out.println("Cluster Size = "+v.size());
	      
		int i=0;
		double avg=0;
		for(i=0;i<v.size();i++)
		{
			//System.out.println("cl["+i+"]"+v.get(i).get());
			avg=avg+v.get(i).get();
		}
		//System.out.println("Avg = "+avg/v.size());
		return avg/v.size();
	}
}
