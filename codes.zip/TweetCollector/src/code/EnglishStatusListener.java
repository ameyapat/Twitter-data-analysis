package code;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import twitter4j.StallWarning;
import twitter4j.Status;
import twitter4j.StatusDeletionNotice;
import twitter4j.StatusListener;

public class EnglishStatusListener implements StatusListener{

	private static final transient Logger LOG = LoggerFactory.getLogger(EnglishStatusListener.class);
	
	@Override
	public void onException(Exception arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onDeletionNotice(StatusDeletionNotice arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onScrubGeo(long arg0, long arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStallWarning(StallWarning arg0) {
		// TODO Auto-generated method stub
		
	}

	/**
	 * Use log4j to write the Tweet Text to disk. Note that 
	 * we only collect Tweet Text content. If you want to collect
	 * additional data, the Status object has several methods including
	 * getUser(), getGeolocation(), and so on. Twitter4j has documentation on
	 * their website on these.
	 */
	@Override
	public void onStatus(Status status) {
		String tweetText = status.getText();
		Vector<String> hash_tags=new Vector<String>();
		if(isEnglish(tweetText) && status.getLang().equalsIgnoreCase("en")) {
			LOG.info(status.getText()+"||||");
			//System.out.println(status.getLang());
			LOG.info("No. of followers = "+status.getUser().getFollowersCount());
			
			try {
				
				   PrintWriter bw=null;
				   File file = new File("mod_tweet.txt");
				     FileWriter fw = new FileWriter(file, true);
				     bw = new PrintWriter(fw);
				    bw.println("|"); 
					bw.print("@"+status.getUser().getScreenName()+"^");
					bw.print(status.getUser().getFollowersCount()+"^");
					//bw.println("\n Original tweet : "+tweetText);
					
					//String hash_tags[]=getHashTags(tweetText);
					//System.out.println(hash_tags[0]);
			tweetText=removeLink(tweetText);
			tweetText=removeMentions(tweetText);
			tweetText=removePunc(tweetText);
			
			StringTokenizer stk=new StringTokenizer(tweetText);
			
		   System.out.println();
			while(stk.hasMoreTokens())
			{
				
				String mod_tweet=new String();
				String tok=stk.nextToken();
				if(tok.charAt(0)=='#')
				{
					System.out.println("Hash tag : "+tok);
					hash_tags.add(tok);
				//	System.out.println(hash_tags.firstElement());
				}
				if(isStopWord(tok))
				{
					mod_tweet=mod_tweet+"";
				}
				else
				{
					mod_tweet=mod_tweet+" "+tok;
				}
				
				  // System.out.print(mod_tweet);
					bw.print(mod_tweet);
					bw.flush();
					
			}
			
			/*Iterator<String> it = hash_tags.iterator();
			while(it.hasNext())
			{
				//System.out.println("hashtag added ->");
				bw.print("hst"+it.next());
				bw.flush();
			}*/
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				
			}
			
		}
			
 			
		
	}

	@Override
	public void onTrackLimitationNotice(int arg0) {
		// TODO Auto-generated method stub
		
	}
	
	/**
	 * Our hack for filtering English tweets. While we could get the language of the user
	 * object returned by status.getUser(), people with an English language set still tweet
	 * in other languages. We simply check if the Tweet text contains non-ASCII characters;
	 * if it does, we do not collect it.
	 * @param tweetText
	 * @return true if tweetText contains no non-ASCII characters, false otherwise
	 */
	public static boolean isEnglish(String tweetText) {
		for(int i = 0;i < tweetText.length();i++) {
			int c = tweetText.charAt(i);
			if(c > 127) {
				return false;
			}
		}
		return true;
	}
	
	public static boolean isStopWord(String token)
	{
		Set<String> sw = new HashSet<String>();
		sw.add("a");
		sw.add("the");
		sw.add("s");
		sw.add("from");
		sw.add("two");
		sw.add("seven");
		sw.add("a");
		sw.add("u");
		sw.add("ir");
		sw.add("iv");
		sw.add("able");
		sw.add("about");
		sw.add("above");
		sw.add("according");
		sw.add("across");
		sw.add("actually");
		sw.add("after");
		sw.add("afterwards");
		sw.add("again");
		sw.add("all");
		sw.add("also");
		sw.add("although");
		sw.add("always");
		sw.add("am");
		sw.add(".");
		sw.add("s");
		sw.add("known");
		sw.add("many");
		sw.add("made");
		sw.add("most");
		sw.add("named");
		sw.add("than");
		sw.add("well");
		sw.add("between");
		sw.add("based");
		sw.add("called");
		sw.add("t");
		sw.add("out");
		sw.add("b");
		sw.add("among");
		sw.add("amongst");
		sw.add("an");
		sw.add("h");
		sw.add("i");
		sw.add("k");
		sw.add("I");
		sw.add("and");
		sw.add("another");
		sw.add("any");
		sw.add("anyway");
		sw.add("are");
		sw.add("around");
		sw.add("as");
		sw.add("ask");
		sw.add("at");
		sw.add("other");
		sw.add("used");
		sw.add("more");
		sw.add("into");
		sw.add("being");
		sw.add("new");
		sw.add("both");
		sw.add("part");
		sw.add("found");
		sw.add("created");
		sw.add("because");
		sw.add("became");
		sw.add("be");
		sw.add("several");
		sw.add("been");
		sw.add("but");
		sw.add("by");
		sw.add("can");
		sw.add("cannot");
		sw.add("-");
		sw.add("cant");
		sw.add("could");
		sw.add("did");
		sw.add("do");
		sw.add("does");
		sw.add("doing");
		sw.add("done");
		sw.add("down");
		sw.add("downwards");
		sw.add("during");
		sw.add("each");
		sw.add("etc");
		sw.add("even");
		sw.add("ever");
		sw.add("every");
		sw.add("everybody");
		sw.add("far");
		sw.add("few");
		sw.add("first");
		sw.add("followed");
		sw.add("following");
		sw.add("follows");
		sw.add("for");
		sw.add("formerly");
		sw.add("forth");
		sw.add("further");
		sw.add("furthermore");
		sw.add("get");
		sw.add("gets");
		sw.add("getting");
		sw.add("gives");
		sw.add("go");
		sw.add("goes");
		sw.add("had");
		sw.add("hardly");
		sw.add("has");
		sw.add("have");
		sw.add("having");
		sw.add("he");
		sw.add("hello");
		sw.add("hence");
		sw.add("her");
		sw.add("hers");
		sw.add("herself");
		sw.add("hi");
		sw.add("him");
		sw.add("himself");
		sw.add("his");
		sw.add("how");
		sw.add("ie");
		sw.add("if");
		sw.add("in");
		sw.add("is");
		sw.add("it");
		sw.add("its");
		sw.add("itself");
		sw.add("just");
		sw.add("later");
		sw.add("latter");
		sw.add("let");
		sw.add("like");
		sw.add("liked");
		sw.add("likely");
		sw.add("may");
		sw.add("maybe");
		sw.add("me");
		sw.add("mean");
		sw.add("my");
		sw.add("myself");
		sw.add("namely");
		sw.add("nd");
		sw.add("near");
		sw.add("nearly");
		sw.add("necessary");
		sw.add("need");
		sw.add("needs");
		sw.add("neither");
		sw.add("never");
		sw.add("nevertheless");
		sw.add("no");
		sw.add("nobody");
		sw.add("non");
		sw.add("nor");
		sw.add("normally");
		sw.add("not");
		sw.add("nothing");
		sw.add("novel");
		sw.add("now");
		sw.add("of");
		sw.add("off");
		sw.add("often");
		sw.add("oh");
		sw.add("on");
		sw.add("one");
		sw.add("ones");
		sw.add("only");
		sw.add("or");
		sw.add("our");
		sw.add("ours");
		sw.add("ourselves");
		sw.add("over");
		sw.add("own");
		sw.add("per");
		sw.add("perhaps");
		sw.add("provides");
		sw.add("que");
		sw.add("quite");
		sw.add("rather");
		sw.add("really");
		sw.add("reasonably");
		sw.add("right");
		sw.add("said");
		sw.add("same");
		sw.add("saw");
		sw.add("say");
		sw.add("says");
		sw.add("see");
		sw.add("seeing");
		sw.add("seems");
		sw.add("seen");
		sw.add("self");
		sw.add("selves");
		sw.add("sent");
		sw.add("seriously");
		sw.add("she");
		sw.add("should");
		sw.add("since");
		sw.add("so");
		sw.add("some");
		sw.add("soon");
		sw.add("still");
		sw.add("sub");
		sw.add("such");
		sw.add("sure");
		sw.add("take");
		sw.add("taken");
		sw.add("tell");
		sw.add("tends");
		sw.add("that");
		sw.add("thats");
		sw.add("the");
		sw.add("their");
		sw.add("theirs");
		sw.add("them");
		sw.add("themselves");
		sw.add("then");
		sw.add("thence");
		sw.add("there");
		sw.add("thereafter");
		sw.add("these");
		sw.add("they");
		sw.add("think");
		sw.add("third");
		sw.add("this");
		sw.add("those");
		sw.add("though");
		sw.add("three");
		sw.add("through");
		sw.add("throughout");
		sw.add("thru");
		sw.add("thus");
		sw.add("to");
		sw.add("too");
		sw.add("took");
		sw.add("toward");
		sw.add("towards");
		sw.add("tried");
		sw.add("tries");
		sw.add("truly");
		sw.add("try");
		sw.add("trying");
		sw.add("twice");
		sw.add("un");
		sw.add("under");
		sw.add("unto");
		sw.add("up");
		sw.add("upon");
		sw.add("us");
		sw.add("use");
		sw.add("very");
		sw.add("via");
		sw.add("viz");
		sw.add("wants");
		sw.add("was");
		sw.add("we");
		sw.add("went");
		sw.add("were");
		sw.add("what");
		sw.add("whatever");
		sw.add("when");
		sw.add("whence");
		sw.add("whenever");
		sw.add("where");
		sw.add("whereafter");
		sw.add("whereas");
		sw.add("whereby");
		sw.add("wherein");
		sw.add("whereupon");
		sw.add("wherever");
		sw.add("whether");
		sw.add("which");
		sw.add("while");
		sw.add("who");
		sw.add("whom");
		sw.add("whose");
		sw.add("why");
		sw.add("will");
		sw.add("with");
		sw.add("would");
		sw.add("yet");
		sw.add("you");
		sw.add("your");
		sw.add("yours");
		sw.add("yourself");
		sw.add("yourselves");
		sw.add("RT");
		sw.add("rt");
		if(sw.contains(token.toLowerCase()))
		return true;
		else return false;
		
	}

	public String removePunc(String tweet)
	{
		
		StringBuilder builder=new StringBuilder();
		for(char c: tweet.toCharArray())
			if(Character.isLetterOrDigit(c) || Character.isSpaceChar(c) || c=='#')
				builder.append(c);
			else
				builder.append(" ");
		return builder.toString();
	}
	
	public String removeLink(String tweet)
	{
		
		String commentstr1=tweet;
        String urlPattern = "((https?|ftp|gopher|telnet|file|Unsure|http):((//)|(\\\\))+[\\w\\d:#@%/;$()~_?\\+-=\\\\\\.&]*)";
        Pattern p = Pattern.compile(urlPattern,Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(commentstr1);
        int i=0;
        while (m.find()) {
            commentstr1=commentstr1.replaceAll(m.group(i),"").trim();
            i++;
        }
        return commentstr1;
	}
	
	public String removeMentions(String tweet)
	{
		
		StringTokenizer stk=new StringTokenizer(tweet);
		StringBuilder builder=new StringBuilder();
		while(stk.hasMoreTokens())
		{
			String temp=stk.nextToken();
		if(temp.contains("@"))
		{
			builder.append("");
		}
		else
			builder.append(temp+" ");
		}
		return builder.toString();
	}
	

}


